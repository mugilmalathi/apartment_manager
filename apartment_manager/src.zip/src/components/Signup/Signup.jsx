export const Signup = ()=>{
    return (
        <div>
        <h4>SIGNUP</h4>
        <label>User Name</label>
        <br />
        <input type="text" />
        <br />
        <label>Email</label>
        <br />
        <input type="text" />
        <br />
        <label>Mobile No</label>
        <br />
        <input type="number" />
        <br />
        <label>Password</label>
        <br />
        <input type="text" />
        <br />
        <button>SignUp</button>
    </div>
    )
}