import "./Flat.css";

export const Flat = ()=>{
    return (
        <div className="main">
            <h1>Flat Details</h1>
        </div>
    )
}