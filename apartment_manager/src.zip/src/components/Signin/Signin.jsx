export const Signin = ()=>{
    return (
        <div>
            <h4>SIGNIN</h4>
            <label>User Name</label>
            <br />
            <input type="text" />
            <br />
            <label>Password</label>
            <br />
            <input type="text" />
            <br />
            <button>SignIn</button>
        </div>
    )
}